import java.io.Serializable;
/**
 * Vartojo klasė saugo prisijungsio vardą ir pavardę.
 * Ateity vartotojas jungsis su prisijungimu ir slaptažodžiu.
 */
public class User implements Serializable {
    public String name;
    public String surname;
    private String login;
    private String password;

    public User(String name, String surname) {
        this.name = name;
        this.surname = surname;

    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                '}';
    }
}
