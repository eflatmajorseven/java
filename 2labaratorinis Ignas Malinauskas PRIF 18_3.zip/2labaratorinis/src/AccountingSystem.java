
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

/**
 * Pagrindinė buhalterinės sistemos klasė, kurioje saugomi
 * kategorijų, naudotojų ir kompanijos duomenys. Šioje klasėje
 * yra skaičiuojamas visas kompanijos balansas bei turi kompanijos pavadinimo
 * ir e. pašto keitimo metodus.
 */

public class AccountingSystem implements Serializable {
  private String companyName;
  private String email;
  private Date dateCreated;
  private String systemVersion;
  private ArrayList<Category> categories = new ArrayList<Category>();
  private ArrayList<User> systemUsers = new ArrayList<User>();
  private double balance;


    public AccountingSystem(String companyName, String email, Date dateCreated, String systemVersion) {
        this.companyName = companyName;
        this.email = email;
        this.dateCreated = dateCreated;
        this.systemVersion = systemVersion;
        this.balance=0;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public ArrayList<Category> getCategories() {
        return categories;
    }

    public ArrayList<User> getSystemUsers() {
        return systemUsers;
    }

    public void setSystemUsers(ArrayList<User> systemUsers) {
        this.systemUsers = systemUsers;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance + this.balance ;
    }

    @Override
    public String toString() {
        return "AccountingSystem{" +
                "companyName='" + companyName + '\'' +
                ", email='" + email + '\'' +
                ", dateCreated=" + dateCreated +
                ", systemVersion='" + systemVersion + '\'' +
                ", categories=" + categories +
                ", systemUser=" + systemUsers +
                '}';
    }
    public static void updateAccountingSystem(Scanner scan, AccountingSystem asis){
        System.out.println("Select what to update: name; email;");
        String cmd = scan.next();
        switch (cmd){
            case "name":
                System.out.println("Update name");
                asis.setCompanyName(scan.next());
                break;
            case "email":
                System.out.println("Update email");
                asis.setEmail(scan.next());
                break;
        }
    }

}
