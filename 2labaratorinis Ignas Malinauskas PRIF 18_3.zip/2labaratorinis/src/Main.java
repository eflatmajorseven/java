import lombok.Data;

import java.io.*;
import java.sql.SQLOutput;
import java.util.Calendar;
import java.util.Scanner;

/**
 *  Main klasėje sukuriama nauja arba nuskaitoma esanti sistema,
 *  pateikiamas pirminis opcijų sąrašas vartotojui,
 *  sistemos darbo pabaigoje eksportuojami duomenys į failą.
 */
public class Main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        AccountingSystem asis = null;
        
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("AccountingSystemDB.afv"));
            asis = (AccountingSystem) in.readObject();
            in.close();
        }

        catch (FileNotFoundException e){
      System.out.println("no fail");
        }

        User user = new User("rokis", "balbo");
        Scanner scan = new Scanner(System.in);
        String cmd = "";
        System.out.println("Welcome aboard Captain "+user.name +"!");

        if (asis == null){
            System.out.println("Create an accounting system: {Company name};{Email};" );
            cmd = scan.nextLine();
            String [] accInfo = cmd.split(";");
            asis = new AccountingSystem(accInfo[0],accInfo[1], Calendar.getInstance().getTime(),"systemVersion: 1.0 "  );

        }


        while (!(cmd.equals("quit"))){
      System.out.println(asis.getCompanyName() + " " + asis.getEmail());
            System.out.println("Choose your destiny:");
            System.out.println("-----------------------------------");
            System.out.println("\t Manage categories: mng  \n" +
                            "\t Update Company info: up  \n"+
                    "\t Quit work: quit  \n");
            cmd = scan.next();
            switch (cmd) {
                case "mng":{
                    CategoryManagement.manageCategories(scan, asis, user);
                    break;
                }
                case "up":{
                    AccountingSystem.updateAccountingSystem(scan, asis);
                    break;
                }
                case "quit":{
                    break;
                }
                default:
          System.out.println("chck yo letters");
      }
        }
        ObjectOutputStream out = null;
        try {out = new ObjectOutputStream(new FileOutputStream("AccountingSystemDB.afv"));
            out.writeObject(asis);
        }
        catch (IOException e) {
      System.out.println("Kazkas negerai su failu://");
        }
        finally {
            if (out!=null)
                out.close();
        }
    }
}
