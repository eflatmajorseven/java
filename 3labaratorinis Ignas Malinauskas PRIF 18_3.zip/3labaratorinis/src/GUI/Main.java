 package GUI;

 import AccountingSystem.AccountingSystem;
 import AccountingSystem.DataRW;
 import javafx.application.Application;
 import javafx.application.Platform;
 import javafx.event.EventHandler;
 import javafx.fxml.FXMLLoader;
 import javafx.scene.Parent;
 import javafx.scene.Scene;
 import javafx.stage.Stage;
 import javafx.stage.WindowEvent;
 /**
  Trumpas komentaras apie programą. Iš pradžių ieškomas AccountingSystem failas, jei toks yra -
  einame į pagrindinį langą, jeigu ne - sukuriam naują. Pradžioj įvestas naudotojas atsakingas už viską.
  Nepavyko grafiškai pavaizduoti medžio, tiesiog pasidaviau. Kuriant kategoriją pelyte nuspaudžiam ant
  kategorijos, kuri bus parent. Duomenų kontrolės nepritaikiau. Duomenys išsisaugo automatiškai
  išjungus programą tiek nuspaudus "X", tiek "Disappear".

  */

 public class Main extends Application {
    AccountingSystem asis = new AccountingSystem();

    @Override
    public void start(Stage primaryStage) throws Exception{
        asis = DataRW.loadLibraryFromFile(asis);
        

       if (asis.getSystemUsers().size() == 0) {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginPage.fxml"));
            Parent root = loader.load();
            primaryStage.setTitle("Accounting System");
            LogInController login = loader.getController();
            login.setAccountingSystem(asis);
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
          }
       else {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.fxml"));
           Parent root = loader.load();
           primaryStage.setTitle("Accounting System");
           MainWindow mainWindow = loader.getController();
           mainWindow.setAccountingSystem(asis);
           primaryStage.setScene(new Scene(root));
           primaryStage.show();
       }

        primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                DataRW.writeLibraryToFile(asis);
                Platform.exit();

            }
        });
    }


    public static void main(String[] args) {
        launch(args);
    }
}
