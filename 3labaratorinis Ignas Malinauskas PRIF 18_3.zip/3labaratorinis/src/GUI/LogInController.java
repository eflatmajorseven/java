package GUI;


import AccountingSystem.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LogInController implements Initializable {

    public TextField nameBar;
    public TextField surnameBar;
    public Button logInButton;
    public TextField CompanyName;
    public TextField CompanyEmail;

    private AccountingSystem asis;
    public void setAccountingSystem (AccountingSystem asis){
        this.asis = asis;

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void logIn(ActionEvent actionEvent) throws IOException {
        asis.getSystemUsers().add(new User(nameBar.getText(),surnameBar.getText()));
        asis.setCompanyName(CompanyName.getText());
        asis.setEmail(CompanyEmail.getText());
        loadMainWindow();

    }
    public void loadMainWindow() throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.fxml"));
        Parent root = loader.load();
        MainWindow mainWindow = loader.getController();
        mainWindow.setAccountingSystem(asis);
        Stage stage = (Stage) logInButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }
}
