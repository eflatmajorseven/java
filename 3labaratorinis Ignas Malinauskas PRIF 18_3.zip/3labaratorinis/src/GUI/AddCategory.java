package GUI;

import AccountingSystem.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class AddCategory implements Initializable {
    public TextField categoryName;
    public TextField categoryDescription;
    public TextField parentCategory;
    public Button addCategoryButton;
    private AccountingSystem asis;



    public void setAccountingSystem(AccountingSystem asis) {
        this.asis = asis;

    }
    public void addingCategories (ActionEvent event) throws IOException {
        ArrayList<User> resUser = new ArrayList<User>();
        resUser.add(asis.getSystemUsers().get(0));

        if (!parentCategory.getText().equals("")) {
            for (Category c : asis.getCategories()) {
//
                recursiveAddingCategories(c, categoryName.getText(), parentCategory.getText(),
                        categoryDescription.getText(), resUser);
            }

        }
        else {
            // sukuria pirmo laipsnio kategoriją
            asis.getCategories()
                    .add(
                            new Category(
                                    categoryName.getText(), categoryDescription.getText(), LocalDate.now(), resUser, new ArrayList<Category>(), parentCategory.getText(),
                            new ArrayList<Income>(), new ArrayList<Expense>()));


        }


        FXMLLoader loader = new FXMLLoader(getClass().getResource("ManageCategories.fxml"));
        Parent root = loader.load();
        ManageCategories manageCategories = loader.getController();
        manageCategories.setAccountingSystem(asis);
        Stage stage = (Stage) addCategoryButton.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    }


    public static Boolean recursiveAddingCategories(Category currentCategory, String newCategory, String parentCategory, String categoryDescription, ArrayList<User> resUser){

                if (currentCategory.getName().equals(parentCategory)){
                    currentCategory.getSubCategory().add(new Category(
                            newCategory, categoryDescription, LocalDate.now(), resUser, new ArrayList<Category>(),parentCategory ,
                            new ArrayList<Income>(), new ArrayList<Expense>()));
                    return true;
                }
                else {
                    for (Category subc : currentCategory.getSubCategory())
                        if (recursiveAddingCategories(subc,newCategory,parentCategory,categoryDescription,resUser))
                            return true;
                }
                return false;

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {


    }



}
