package AccountingSystem;//package AccountingSystem;
//
//import java.time.LocalDate;
//import java.util.ArrayList;
//import java.util.Scanner;
//
//
//public class CategoryManagement {
//  public static void manageCategories(Scanner scan, AccountingSystem asis, User user) {
//    String catCmd = "";
//
//    while ((!catCmd.equals("quit"))) {
//      System.out.println(
//          "Manage categories: \n"
//              + "\t---------------------------- \n"
//              + "\t Add Category : addcat \n" +
//              "\t View Categories: viewcat\n"
//              +"\t Update Category: upcat\n"
//              +"\t Delete Category: delcat\n"+
//              "\t End work: quit\n"
//              + "\t---------------------------- \n");
//      catCmd = scan.next();
//      switch (catCmd) {
//        case "addcat":
//          addCategory(scan, asis, user);
//          break;
//        case "viewcat":
//           printAllCategories(asis);
//          break;
//        case "upcat":
//          updateCategory(scan, asis);
//          break;
//        case "delcat":
//          deleteCategory (scan,asis);
//      }
//    }
//  }
//
//
//
//  public static void addCategory(Scanner scan, AccountingSystem asis, User user) {
//    ArrayList<User> resUser = new ArrayList<User>();
//    resUser.add(user);
//    ArrayList<Income> enteredIncome = new ArrayList<>();
//    ArrayList<Expense> enteredExpense = new ArrayList<>();
//
//    System.out.println("Enter category info: name; description; parent Category ('--' if none);");
//            String[] input = scan.next().split(";");
//
//    System.out.println("Add income? (y/n)");
//        String question = scan.next();
//        if (question.equals("y")){
//          enteredIncome = new ArrayList<Income>(addIncome(scan));
//        }
//
//    System.out.println("Add expense? (y/n)");
//        question = scan.next();
//    if (question.equals("y")){
//      enteredExpense = new ArrayList<Expense>(addExpense(scan));
//    }
//
//
//    if (!input[2].equals("--")) {
//      for (Category c:asis.getCategories()){
//               recursiveAddCategory(c, input[2],input[0],input[1], resUser, enteredIncome, enteredExpense) ;
//      }
//
//    } else {
//      // sukuria pirmo laipsnio kategoriją
//      asis.getCategories()
//          .add(
//              new Category(
//                  input[0], input[1], LocalDate.now(), resUser, new ArrayList<Category>()));
//
//    }
//  }
//
//  public static Boolean recursiveAddCategory(
//          Category currentCat,
//          String parentCategoryName,
//          String newCategoryName,
//          String newCategoryDescription,
//          ArrayList<User> responsibleUser,
//          ArrayList<Income> enteredIncome,
//          ArrayList<Expense> enteredExpense) {
//
//    //Patikrina pirmo laipsnio kategorijas
//    if (currentCat.getName().equals(parentCategoryName)) {
//      currentCat
//          .getSubCategory()
//          .add(
//              new Category(
//                  newCategoryName,
//                  newCategoryDescription,
//                  LocalDate.now(),
//                  responsibleUser,
//                  new ArrayList<Category>()
//                      ));
//      return true;
//    } else {
//      //Iesko kategoriju subkategorijose (we have to go deeper)
//      for (Category subcategory : currentCat.getSubCategory()) {
//        if (recursiveAddCategory(
//            subcategory,
//            parentCategoryName,
//            newCategoryName,
//            newCategoryDescription,
//            responsibleUser,
//                enteredIncome,
//                enteredExpense)) {
//          return true;
//        }
//      }
//    }
//    return false;
//  }
//  public static void printAllCategories(AccountingSystem asis){
//asis.setBalance(-asis.getBalance());
//
//    if (asis.getCategories().size()==0){
//      System.out.println("no category");
//    }
//    else {
//      for (Category c:asis.getCategories()){
//        recursivePrintCategory(c, asis );
//
//      }
//      System.out.println("Total balance: "+asis.getBalance());
//      //System.out.println("Total company balance: " + total);
//      }
//
//  }
//public static void recursivePrintCategory (Category category, AccountingSystem asis){
//
//    double categoryBalance = category.getTotalIncome(category.getIncome()) - category.getTotalExpense(category.getExpense());
//    System.out.println(
//        "Kategorija: "
//            + category.getName()
//            + category.getIncome()
//            + "\n"
//            + category.getExpense()
//            + "\n" +
//                 " Total category's income: "+
//                category.getTotalIncome(category.getIncome()) + "\n" +
//                " Total category's expense: " +
//                category.getTotalExpense(category.getExpense()) +"\n"+
//            "Total category's balance:" + categoryBalance);
//    asis.setBalance(categoryBalance);
//
//  if (category.getSubCategory().size() > 0){
//    System.out.print(" Subkategorijos: ");
//    for (Category subcategory :category.getSubCategory()){
//      System.out.print(subcategory.getName() + " ");
//    }
//    System.out.println("\n");
//    for (Category subcategory: category.getSubCategory()){
//      recursivePrintCategory(subcategory, asis);
//    }
//
//  }
//    else {
//      System.out.println(" Nera subkategoriju \n");
//    }
//  }
//
//  public static void updateCategory (Scanner scan, AccountingSystem asis) {
//
//      System.out.println("Enter category name: ");
//      String targetCategory = scan.next();
//
//      for (Category c : asis.getCategories()){
//      recursiveUpdateCategory (scan,asis, targetCategory, c);
//    }
//  }
//
//  public static void recursiveUpdateCategory (Scanner scan, AccountingSystem asis, String targetCategory, Category currentCategory){
//    if (currentCategory.getName().equals(targetCategory)){
//
//    System.out.println(currentCategory.getName() + " " + currentCategory.getDescription());
//      System.out.println("Select what to update: name; description;");
//        String cmd = scan.next();
//        switch (cmd){
//          case "name":
//            System.out.println("Update name");
//
//            currentCategory.setName(scan.next());
//            break;
//          case "description":
//            currentCategory.setDescription(scan.next());
//            break;
//        }
//  }
//   else {
//     for (Category subcategory: currentCategory.getSubCategory()){
//       recursiveUpdateCategory(scan, asis, targetCategory, subcategory);
//     }
//    }
//
//
//  }
//  private static void deleteCategory(Scanner scan, AccountingSystem asis) {
//    System.out.println("Enter category name to delete: ");
//    String targetCategory = scan.next();
//if(asis.getCategories().removeIf(c -> c.getName().equals(targetCategory))){
//
//}
//else {
//  asis.getCategories().removeIf(c -> recursiveDeleteCategory(c,targetCategory));
//}
//
//
////    System.out.println("category, we find not");
// }
//private static boolean recursiveDeleteCategory (Category category, String targetCategory) {
//    if (category.getName().equals(targetCategory)) {
//      return true;
//      }
//    else {
//      category.getSubCategory().removeIf(cat -> recursiveDeleteCategory(cat,targetCategory));
//    }
//    return false;
//    }
//
//
//private static ArrayList<Income> addIncome (Scanner scan){
//  ArrayList<Income> enteredIncome = new ArrayList<Income>();
//
//  System.out.println("Enter income: name ; amount ; 'stop' to stop:)");
//  String cmd = " ";
//  while (!cmd.equals("stop")){
//    cmd = scan.next();
//    if (!cmd.equals("stop")){
//      String[] inputIncome = cmd.split(";");
//      enteredIncome.add(new Income(inputIncome[0], Double.parseDouble(inputIncome[1])) ) ;
//
//    }
//
//  }
//return enteredIncome;
//  }
//
//private static ArrayList<Expense> addExpense(Scanner scan){
//  ArrayList<Expense> enteredExpense = new ArrayList<Expense>();
//  System.out.println("Enter expense: name ; amount ; 'stop' to stop:)");
//  String cmd = " ";
//  while (!cmd.equals("stop")){
//    cmd = scan.next();
//    if (!cmd.equals("stop")){
//      String[] inputExpense = cmd.split(";");
//      enteredExpense.add(new Expense(inputExpense[0], Double.parseDouble(inputExpense[1])) ) ;
//
//    }
//
//  }
//  return enteredExpense;
//  }
//
//}
