package AccountingSystem;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;


public class Category implements Serializable {
    private String name;
    private String description;
    private LocalDate dateCreated;
    private ArrayList<User> responsibleUser;
    private ArrayList<Category> subCategory ;
    private ArrayList<Income> income ;
    private ArrayList<Expense> expense ;
    private String parentCategory;

    public Category() {

    }


    public Category(String name, String description,LocalDate dateCreated,
                    ArrayList<User> responsibleUser , ArrayList<Category> subCategory,
                    String parentCategory, ArrayList<Income> income, ArrayList <Expense> expense) {
        this.name = name;
        this.description = description;
        this.dateCreated = dateCreated;
        this.responsibleUser = responsibleUser;
        this.subCategory = subCategory;
        this.parentCategory = parentCategory;
        this.income = income;
        this.expense = expense;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(LocalDate dateCreated) {
        this.dateCreated = dateCreated;
    }

    public ArrayList<User> getResponsibleUser() {
        return responsibleUser;
    }

    public void setResponsibleUser(ArrayList<User> responsibleUser) {
        this.responsibleUser = responsibleUser;
    }

    public ArrayList<Category> getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(ArrayList<Category> subCategory) {
        this.subCategory = subCategory;
    }

    public ArrayList<Income> getIncome() {
        return income;
    }

    public void setIncome(ArrayList<Income> income) {
        this.income = income;
    }

    public ArrayList<Expense> getExpense() {
        return expense;
    }

    public void setExpense(ArrayList<Expense> expense) {
        this.expense = expense;
    }

    public String getParentCategory() {
        return parentCategory;
    }

    public void setParentCategory(String parentCategory) {
        this.parentCategory = parentCategory;
    }

    public double getTotalIncome (ArrayList<Income> income){
        double totalIncome = 0;
            for (Income i: income){
                 totalIncome = i.getAmount() + totalIncome;
            }
    return totalIncome;}

    public double getTotalExpense (ArrayList<Expense> expense){
        double totalExpense = 0;
        for (Expense e: expense){
            totalExpense = e.getAmount() + totalExpense;
        }
        return totalExpense;}
    public double getBalance(){
        double categoryBalance = getTotalIncome(this.income) - getTotalExpense(this.expense);
        return categoryBalance;
    }

    @Override
    public String toString() {
        return "Category:" +
                 name + '\'' +
                ", description" + description + '\'' +
                ", dateCreated=" + dateCreated +
                ", responsibleUser=" + responsibleUser +
                ", subCategory=" + subCategory +
                "income:  " + income + "  expese: " + expense +
                "\n";
    }
}
