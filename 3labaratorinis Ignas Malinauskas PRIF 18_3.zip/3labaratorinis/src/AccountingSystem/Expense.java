package AccountingSystem;
import java.io.Serializable;

public class Expense implements Serializable {
  private String name;
  private double amount;

    public Expense() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Expense(String name, double amount) {
        this.name = name;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return  "\t Name: " + name  +
                "\t " + amount + "\n";

    }
}

