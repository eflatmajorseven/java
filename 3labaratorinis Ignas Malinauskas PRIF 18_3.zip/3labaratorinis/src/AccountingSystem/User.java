package AccountingSystem;

import java.io.Serializable;


public class User implements Serializable {
    public String name;
    public String surname;
    private String login;
    private String password;

    public User(String name, String surname) {
        this.name = name;
        this.surname = surname;

    }

    @Override
    public String toString() {
        return  name +" "+ surname;
    }
}
