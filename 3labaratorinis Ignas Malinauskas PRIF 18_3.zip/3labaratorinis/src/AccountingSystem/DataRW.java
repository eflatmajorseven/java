package AccountingSystem;



import java.io.*;

public class DataRW {

    public static AccountingSystem loadLibraryFromFile(AccountingSystem asis) {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("AccountingSystem.lib"));
            asis = (AccountingSystem) ois.readObject();
            ois.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Failed with class recognition.");
        } catch (IOException e) {
            //e.printStackTrace();
            System.out.println("Failed to open file.");
        }
        return asis;
    }

    public static void writeLibraryToFile(AccountingSystem asis) {
        try {
      ObjectOutputStream out =
          new ObjectOutputStream(new FileOutputStream("AccountingSystem.lib"));
            out.writeObject(asis);
            out.close();
        } catch (IOException e) {
            System.out.println("Fail.\n");
        }
    }
}
